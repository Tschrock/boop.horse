Hello!

Thank you very much for using my application <3
To utilize this skin, you must first download the application BoopThePony at the following link https://ko-fi.com/s/5de6042f35

To install the skin:
- Close the "Boop the Pony" application
- Open the application folder
- Open the Assets folder
- Copy the current Skin folder inside the Assets folder
- Launch the app!

To change the skin, access the in application menu by clicking on the cutiemark icon. 
Select a skin by clicking on the arrows!
IMPORTANT: Please let each skin load when changing skins. 

In case of doubt, check the visual installation guide